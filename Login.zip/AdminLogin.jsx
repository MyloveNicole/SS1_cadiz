import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      const res = await fetch('http://localhost:5000/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!data.success) {
        setErr(data.error || 'Login failed');
        return;
      }
      localStorage.setItem('cleanup_token', data.token);
      localStorage.setItem('cleanup_admin', JSON.stringify(data.admin));
      navigate('/admin/dashboard');
    } catch (e) {
      setErr('Network error');
    }
  };

  return (
    <div style={{ maxWidth: 420, margin: '6rem auto', padding: 20, border: '1px solid #ddd', borderRadius: 8 }}>
      <h2>Admin Login</h2>
      <form onSubmit={submit}>
        <div style={{ marginBottom: 12 }}>
          <label>Email</label>
          <input value={email} onChange={e => setEmail(e.target.value)} required style={{ width: '100%', padding: 8 }} />
        </div>
        <div style={{ marginBottom: 12 }}>
          <label>Password</label>
          <input value={password} onChange={e => setPassword(e.target.value)} required type="password" style={{ width: '100%', padding: 8 }} />
        </div>
        {err && <div style={{ color: 'red', marginBottom: 12 }}>{err}</div>}
        <button type="submit" style={{ padding: '8px 12px' }}>Login</button>
      </form>
    </div>
  );
}
