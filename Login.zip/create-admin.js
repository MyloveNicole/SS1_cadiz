const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const USERS_FILE = path.join(__dirname, 'users.json');

function readUsers() {
  try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); } catch { return { users: [] }; }
}
function writeUsers(data) { fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2)); }

const readline = require('readline').createInterface({ input: process.stdin, output: process.stdout });
readline.question('Admin name: ', name => {
  readline.question('Admin email: ', email => {
    readline.question('Admin password: ', password => {
      const data = readUsers();
      if (data.users.find(u => u.email === email)) {
        console.log('User already exists');
        readline.close();
        return;
      }
      const hashed = bcrypt.hashSync(password, 10);
      data.users.push({
        id: uuidv4(),
        name,
        email,
        passwordHash: hashed,
        role: 'admin',
        createdAt: new Date().toISOString()
      });
      writeUsers(data);
      console.log('Admin created');
      readline.close();
    });
  });
});
