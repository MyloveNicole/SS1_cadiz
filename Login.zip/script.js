import express from "express";
import nodemailer from "nodemailer";
import bodyParser from "body-parser";
import cors from "cors";
import fs from "fs";
import crypto from "crypto";

const app = express();
app.use(cors());
app.use(bodyParser.json());

const USERS_FILE = "./users.json";

// 🔧 Gmail transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "your_email@gmail.com",
    pass: "your_app_password"
  }
});

// 🔹 Utility functions
const readUsers = () => JSON.parse(fs.readFileSync(USERS_FILE));
const saveUsers = (users) => fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

// 📨 Send password reset email
app.post("/send-reset", async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ success: false, error: "Email is required" });

  const users = readUsers();
  const user = users.find(u => u.email === email);
  if (!user) return res.status(404).json({ success: false, error: "Email not found" });

  // Generate unique token and expiry (1 hour)
  const token = crypto.randomBytes(20).toString("hex");
  const expiry = Date.now() + 3600000; // 1 hour

  user.resetToken = token;
  user.resetTokenExpiry = expiry;
  saveUsers(users);

  const resetLink = `http://localhost:5500/reset-password.html?token=${token}`;

  try {
    await transporter.sendMail({
      from: '"CleanUp Support" <your_email@gmail.com>',
      to: email,
      subject: "Reset Your CleanUp Password",
      html: `
        <h3>Hello,</h3>
        <p>Click below to reset your password:</p>
        <a href="${resetLink}" style="color:#2E7D32;font-weight:bold;">Reset Password</a>
        <p>This link will expire in 1 hour.</p>
      `
    });

    res.json({ success: true, message: "Password reset email sent." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: "Failed to send email" });
  }
});

// 🔹 Reset password endpoint
app.post("/reset-password", (req, res) => {
  const { token, newPassword } = req.body;
  if (!token || !newPassword) return res.status(400).json({ success: false, error: "Missing data" });

  const users = readUsers();
  const user = users.find(u => u.resetToken === token && u.resetTokenExpiry > Date.now());
  if (!user) return res.status(400).json({ success: false, error: "Invalid or expired token" });

  user.password = newPassword; // In real apps, hash passwords!
  user.resetToken = null;
  user.resetTokenExpiry = null;
  saveUsers(users);

  res.json({ success: true, message: "Password reset successfully!" });
});

app.listen(3000, () => console.log("✅ Server running on http://localhost:3000"));
// 🟢 Register resident
app.post("/register", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, error: "Email and password required" });

  const users = readUsers();
  if (users.find(u => u.email === email)) return res.status(400).json({ success: false, error: "Email already registered" });

  const newUser = {
    id: users.length + 1,
    email,
    password, // In real apps, hash this
    resetToken: null,
    resetTokenExpiry: null
  };
  users.push(newUser);
  saveUsers(users);
  res.json({ success: true, message: "Registration successful!" });
});

// 🟢 Login resident
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, error: "Email and password required" });

  const users = readUsers();
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(400).json({ success: false, error: "Invalid email or password" });

  res.json({ success: true, message: "Login successful!" });
});
