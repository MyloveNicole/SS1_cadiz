import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function apiGet(path) {
  const token = localStorage.getItem('cleanup_token');
  return fetch(`http://localhost:5000${path}`, {
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }
  }).then(r => r.json());
}

function apiPatch(path, body) {
  const token = localStorage.getItem('cleanup_token');
  return fetch(`http://localhost:5000${path}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  }).then(r => r.json());
}

export default function Dashboard() {
  const [residents, setResidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadResidents();
  }, []);

  async function loadResidents() {
    setLoading(true);
    const data = await apiGet('/api/admin/residents');
    if (!data.success) {
      // token invalid or other error
      localStorage.removeItem('cleanup_token');
      navigate('/admin/login');
      return;
    }
    setResidents(data.residents);
    setLoading(false);
  }

  async function markCollected(residentId, recordId) {
    const res = await apiPatch(`/api/admin/residents/${residentId}`, {
      updateWasteRecord: {
        recordId,
        fields: { status: 'collected', updatedAt: new Date().toISOString() }
      }
    });
    if (res.success) loadResidents();
  }

  function logout() {
    localStorage.removeItem('cleanup_token');
    localStorage.removeItem('cleanup_admin');
    navigate('/admin/login');
  }

  if (loading) return <div style={{ padding: 20 }}>Loading...</div>;

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Admin Dashboard</h2>
        <div>
          <button onClick={logout}>Logout</button>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        {residents.length === 0 && <div>No residents yet.</div>}
        {residents.map(r => (
          <div key={r.id} style={{ border: '1px solid #eee', padding: 12, borderRadius: 8, marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <strong>{r.name}</strong> <div style={{ fontSize: 12 }}>{r.email} — {r.address}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 12 }}>Joined: {new Date(r.createdAt).toLocaleDateString()}</div>
              </div>
            </div>

            <div style={{ marginTop: 8 }}>
              <strong>Waste Records</strong>
              {(!r.wasteRecords || r.wasteRecords.length === 0) && <div style={{ marginTop: 6 }}>No records</div>}
              <ul>
                {r.wasteRecords && r.wasteRecords.map(record => (
                  <li key={record.id} style={{ marginTop: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div>{record.date} — {record.type} — <em>{record.status}</em></div>
                      {record.notes && <div style={{ fontSize: 12 }}>{record.notes}</div>}
                    </div>
                    <div>
                      {record.status !== 'collected' && (
                        <button onClick={() => markCollected(r.id, record.id)}>Mark Collected</button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
