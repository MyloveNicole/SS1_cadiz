const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const USERS_FILE = path.join(__dirname, 'users.json');
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_to_a_long_secret_in_prod';
const JWT_EXPIRES = '4h';

// Helper: read users.json
function readUsers() {
  try {
    const raw = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    return { users: [] };
  }
}

// Helper: write users.json
function writeUsers(data) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2));
}

// Authenticate middleware
function authenticateAdmin(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ success: false, error: 'Missing token' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const users = readUsers().users;
    const admin = users.find(u => u.id === payload.id && u.role === 'admin');
    if (!admin) return res.status(401).json({ success: false, error: 'Invalid token' });
    req.admin = { id: admin.id, email: admin.email, name: admin.name };
    next();
  } catch (err) {
    return res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }
}

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, error: 'Email and password required' });

  const data = readUsers();
  const user = data.users.find(u => u.email === email && u.role === 'admin');
  if (!user) return res.status(400).json({ success: false, error: 'Invalid email or password' });

  const ok = bcrypt.compareSync(password, user.passwordHash);
  if (!ok) return res.status(400).json({ success: false, error: 'Invalid email or password' });

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
  res.json({ success: true, token, admin: { id: user.id, name: user.name, email: user.email } });
});

// Get all residents (protected)
app.get('/api/admin/residents', authenticateAdmin, (req, res) => {
  const data = readUsers();
  const residents = data.users.filter(u => u.role === 'resident').map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    address: u.address || '',
    wasteRecords: u.wasteRecords || [],
    createdAt: u.createdAt
  }));
  res.json({ success: true, residents });
});

// Update a resident (e.g., update waste status) (protected)
app.patch('/api/admin/residents/:id', authenticateAdmin, (req, res) => {
  const rid = req.params.id;
  const updates = req.body; // be explicit in frontend usage
  const data = readUsers();
  const idx = data.users.findIndex(u => u.id === rid && u.role === 'resident');
  if (idx === -1) return res.status(404).json({ success: false, error: 'Resident not found' });

  const resident = data.users[idx];

  // allow patching certain fields only
  if (updates.name) resident.name = updates.name;
  if (updates.address) resident.address = updates.address;
  if (updates.addWasteRecord) {
    const rec = updates.addWasteRecord;
    rec.id = uuidv4();
    resident.wasteRecords = resident.wasteRecords || [];
    resident.wasteRecords.push(rec);
  }
  if (updates.updateWasteRecord) {
    // expects { recordId, fields: { status: 'collected' } }
    const { recordId, fields } = updates.updateWasteRecord;
    resident.wasteRecords = resident.wasteRecords || [];
    const ridx = resident.wasteRecords.findIndex(r => r.id === recordId);
    if (ridx !== -1) {
      resident.wasteRecords[ridx] = { ...resident.wasteRecords[ridx], ...fields };
    }
  }

  data.users[idx] = resident;
  writeUsers(data);
  res.json({ success: true, resident });
});

// Create a new resident (protected)
app.post('/api/admin/residents', authenticateAdmin, (req, res) => {
  const { name, email, address, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ success: false, error: 'name, email and password required' });

  const data = readUsers();
  if (data.users.find(u => u.email === email)) return res.status(400).json({ success: false, error: 'User with email already exists' });

  const hashed = bcrypt.hashSync(password, 10);
  const newUser = {
    id: uuidv4(),
    name,
    email,
    passwordHash: hashed,
    role: 'resident',
    address: address || '',
    wasteRecords: [],
    createdAt: new Date().toISOString()
  };
  data.users.push(newUser);
  writeUsers(data);
  res.json({ success: true, resident: { id: newUser.id, name: newUser.name, email: newUser.email } });
});

// For convenience: endpoint to get admin info (protected)
app.get('/api/admin/me', authenticateAdmin, (req, res) => {
  res.json({ success: true, admin: req.admin });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Cleanup server running on port ${PORT}`);
});
